import sympy
from sympy import oo
from sympy import *
import numpy as np
import scipy
from scipy.integrate import quad

p = 300
n = 300000
x = sympy.Symbol('x')
sum = 0
#solution = quad(func,1,x)
for i in range(1,n,1):
    sum += i**p
fx = sum/(n**(p+1))
#res = sympy.limit(x,fx,oo)
print(fx)

