import numpy as np
import random
import pandas as pd

columsName = ['buying', 'maint', 'doors', 'persons', 'lug-boot', 'safety', 'label']
def getDataSet(file):
    fr = open(file)
    rdata = []
    for line in fr.readlines():
        tmp = line.strip().split(',')
        rdata.append(tmp)
    df = pd.DataFrame(rdata)
    df.columns = columsName
    return df

def getTrainTest(data, trainNum):
    choose = random.sample(range(len(data)), trainNum)
    choose.sort()
    j = 1
    dftrain = pd.DataFrame(columns=columsName)
    dftest = pd.DataFrame(columns=columsName)
    for i in range(1,len(data)):
        if (j < trainNum and i == choose[j]):
            dftrain.loc[dftrain.shape[0]]=data.iloc[i]
            j += 1
        else:
            dftest.loc[dftest.shape[0]] = data.iloc[i]
    return dftrain,dftest

class NBClassify(object):
    def __init__(self):
        _tagProbablity = None
        _featuresProbablity = None

    def train(self,df):
        self._tagProbality = df['label'].value_counts(value for value in df['label'])
        print("各类别的先验概率：\n", self._tagProbality)
        dictFeaturesBase = {}.fromkeys(df.columns)
        for column in df.columns:
            seriesFeature = df[column].value_counts()
            dictFeaturesBase[column] = seriesFeature
        del dictFeaturesBase['label']

        dictFeatures = {}.fromkeys(df['label'])
        for key in dictFeatures.keys():
            dictFeatures[key] = {}.fromkeys([key for key in dictFeaturesBase])
        for key, value in dictFeatures.items():
            for subkey in value.keys():
                value[subkey] = {}.fromkeys([x for x in dictFeaturesBase[subkey].keys()])
        for i in range(0, len(df)):
            label = df.iloc[i]['label']
            for feature in  columsName[0:6]:
                fvalue = df.iloc[i][feature]
                if dictFeatures[label][feature][fvalue] == None:
                    dictFeatures[label][feature][fvalue] = 1
                else:
                    dictFeatures[label][feature][fvalue] += 1
        for tag, featuresDict in dictFeatures.items():
            for featuresName, featureValueDict in featuresDict.items():
                for featureKey, featureValues in featureValueDict.items():
                    if featureValues == None:
                        featureValueDict[featureKey] = 1

        for tag, featuresDict in dictFeatures.items():
            for featuresName, featureValueDict in featuresDict.items():
                totalCount = sum([x for x in featureValueDict.values() if x != None])
                for featureKey, featureValues in featureValueDict.items():
                    featureValueDict[featureKey] = featureValues / totalCount

        self._featuresProbablity = dictFeatures
        print("每个类别下没种特征对应的似然概率为：\n", dictFeatures)

    def classity(self, featureTuple):
        resultDict = {}
        for tag, featuresDict in self._featuresProbablity.items():
            iNumList = []
            i = 0
            for feature, featuresDict in featuresDict.items():
                featureValue = str(featureTuple[i])
                iNumList.append(self._featuresProbablity[tag][feature][featureValue])
                i += 1
            conditionProbablity = 1
            for iNum in iNumList:
                conditionProbablity *= iNum
            resultDict[tag] = self._tagProbality[tag] * conditionProbablity
        resultList = sorted(resultDict.items(), key = lambda  x: x[1], reverse=True)
        return resultList[0][0]

if __name__ == '__main__':
    dfData = getDataSet('car.txt')
    trainData, testData = getTrainTest(dfData, 1500)
    model = NBClassify()
    model.train(trainData)
    errorCount = 0
    for i in range(0, len(testData)):
        result = model.classity(testData.iloc[i][0:6])
        if testData.iloc[i][6] != result: errorCount += 1
    print("The Error rate is %f" %(float(errorCount)/len(testData)))
