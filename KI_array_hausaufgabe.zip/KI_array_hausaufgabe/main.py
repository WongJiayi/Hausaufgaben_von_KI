import random
import pandas as pa

import numpy
import pandas as pd
from numpy import *

def Fun_add(array1,array2):
    A = array1
    B = array2
    if(shape(A) == shape(B)):
        return A+B
    else:
        return '不同类型array不能相加'

def Fun_iden_T(array1,array2):
    A = array1
    B = array2
    C = transpose(dot(A,B))
    D = dot(B.T, A.T)
    if(allclose(C, D)):
        return True
    else:
        return False

def Fun_diag(array1):
    A = triu(array1,0)
    return A+A.T-diag(diag(A))

def Fun_iden_diag(array1):
    if(allclose(array1.T, array1)):
        return True
    else:
        return False

def Fun_print(array1):
    A = array1
    print("A的各行向量:")
    for i in range(shape(A)[0]):
        print("A的", i , "行：" , A[i,:].reshape(1, -1))
    print("A的各列向量:")
    for i in range(shape(A)[1]):
        print("A的", i , "列：" , A[:,i].reshape(-1, 1))

def Fun_ina(array1):
    A = array1
    if(linalg.det(A)):
        print(linalg.inv(A))
    else:
        print("此矩阵没有逆矩阵")


arr = random.randint(1,16,size=[4,4])
ey = eye(3)
id = identity(5)
a = [1,2,3,4,5]
arr1 = diag(diag(arr))
upper_arr = triu(arr,0)
low_arr = tril(arr,0)

A = random.randint(1,30,size=[3,2])
B = random.randint(3,20,size=[3,2])

#Fun_print(A)
#print(pd.DataFrame(A))

C = array([[1, 2, 3],[2, 2, 1],[3, 4, 3]])
Fun_ina(C)

#res = Fun_add(A,B)
#C = A.dot(B)

#print(A,'\n\n',A.T,'\n\n',transpose(A))
#print(Fun_iden_T(A,B))
#print(Fun_diag(A))
#print(Fun_iden_diag(Fun_diag(A)))

A = [[1,2,3]]
if(allclose(array(A).reshape(1,-1), array(A).reshape(1,3))):
    print(True)
else:
    print(False)