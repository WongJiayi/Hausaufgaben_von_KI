import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt
import matplotlib.style as style
from IPython.core.display import HTML

#% matplotlib inline
#style.use('fivethiertyeight')
plt.rcParams["figure.figsize"] = (14,7)
plt.figure(dpi=100)

def Fun_norm():
    plt.plot(np.linspace(-4, 4, 100),
             stats.norm.pdf(np.linspace(-4, 4, 100))
             / np.max(stats.norm.pdf(np.linspace(-4, 4, 100))), )
    plt.fill_between(np.linspace(-4, 4, 100),
                     stats.norm.pdf(np.linspace(-4, 4, 100))
                     / np.max(stats.norm.pdf(np.linspace(-4, 4, 100))),
                     alpha=.15)

    plt.plot(np.linspace(-4, 4, 100),
             stats.norm.pdf(np.linspace(-4, 4, 100), scale=2, loc=1)
             / np.max(stats.norm.pdf(np.linspace(-4, 4, 100))), )
    plt.fill_between(np.linspace(-4, 4, 100),
                     stats.norm.pdf(np.linspace(-4, 4, 100), scale=2, loc=1)
                     / np.max(stats.norm.pdf(np.linspace(-4, 4, 100))),
                     alpha=.15)

    plt.plot(np.linspace(-4, 4, 100), stats.norm.cdf(np.linspace(-4, 4, 100)), )

    plt.title("norm,pdf,cdf")
    plt.text(x=-1.5, y=.7, s="pdf(normed)", rotation=65,
             alpha=.75, weight="bold", color="#008fd5")
    plt.text(x=-.4, y=.5, s="cdf(normed)", rotation=55,
             alpha=.75, weight="bold", color="#fc4f30")
    plt.text(x=.5, y=.3, s="$ \sigma = 2, \mu = 1$", rotation=35, alpha=.75,
             weight="bold", color="#fc4f30")

    print("P(-0.2<x<0.2) = {}".format(stats.norm.cdf(0.2)-stats.norm.cdf(-0.2)))

def Fun_binom():
    plt.bar(x=np.arange(20),
            height=(stats.binom.pmf(np.arange(20), p=.5, n=20)),
            width=.75, alpha=.75)
    plt.plot(np.arange(20),
             stats.binom.cdf(np.arange(20), p=.5, n=20),
             color="#fc4f30")
    plt.scatter(np.arange(20),
                stats.binom.pmf(np.arange(20), p=.5, n=20),
                alpha=.75, s=100)

    plt.text(x=8, y=.2, s="pmf(normed)",alpha=.75, weight="bold", color="#008fd5")
    plt.text(x=14.5, y=.9, s="cmf", alpha=.75, weight="bold", color="#fc4f30")

    print("P(X=1) = {}".format(stats.binom.pmf(k = 1, p=0.3, n=10)))

def Fun_possion():
    plt.bar(x=np.arange(20),
            height=(stats.poisson.pmf(np.arange(20), mu=5)),
            width=.75, alpha=.75)
    plt.plot(np.arange(20),
            stats.poisson.pmf(np.arange(20), mu=5),
            alpha=.75)
    plt.fill_between(np.arange(20),
            stats.poisson.pmf(np.arange(20), mu=5),
            alpha=.75)

    plt.plot(np.arange(20),
            (stats.poisson.cdf(np.arange(20), mu=5)),
            alpha=.75)

    plt.text(x=8, y=.45, s="pmf(normed)", alpha=.75, weight=.8, color="#008fd5")
    plt.text(x=8, y=.9, s="cdf", alpha=.75, weight="bold", color="#fc4f30")

    print("P(X=1) = {}".format(stats.poisson.pmf(k=1, mu=5)))

Fun_norm()
#Fun_binom()
#Fun_possion()

plt.tick_params(axis='both', which='major', labelsize=18)
plt.axhline(y=0, color='black', linewidth=1.3, alpha=.7)



plt.show()