import numpy as np
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV
import matplotlib.pyplot as plt
from sklearn.datasets import make_circles
from pylab import *
#mpl.rcParams['font.sans-serif'] = ['SimHei']

from matplotlib.font_manager import FontProperties
#plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]
def getChineseFont():
    return FontProperties(fname='/Users/enya/Documents/字体/新建文件夹 (2)/2.ttf')
plt.rcParams['axes.unicode_minus'] = False

#线性核函数
def linear(X, Y):
    K = X.T.dot(Y)
    return K

#RBF
def gaussian(X, Y, sigma):
    K = np.exp( -np.linalg.norm(X-Y)**2 / (2 * sigma**2))
    return K

#多项式函数
def poly(X, Y, gamma, c, degree):
    K = X.T.dot(Y)
    K = (gamma*K + c)**degree
    return K

def linear_Fountion():
    x = np.array([[4, 3], [3, 3], [1, 1]])
    y = np.array([1, 1, -1])
    print("训练集（最右一列为标签）：\n", np.hstack((x, y.reshape(3, 1))))
    # 调用SVC，训练算法
    model = SVC(kernel='linear')
    model.fit(x, y)
    # 预测数据
    predict_val = model.predict([[4, 5], [0, 0], [1, 3]])
    print("预测数据【4，5】，【0，0】，【1，3】的类型值分别为：", predict_val)
    # 相关方法和返回值
    w = model.coef_[0]  # 获取w
    a = -w[0] / w[1]  # 斜率
    print("支持向量：\n", model.support_vectors_)
    print("支持向量的标号：", model.support_)
    print("每类支持向量的个数：", model.n_support_)
    print("数据集X到分类超平面的距离：", model.decision_function(x))
    print("参数（法向量）w=", w)
    print("分类线的斜率a=", a)

def plot_decision_boundary(model,X,y,h=0.03,draw_SV = True,title = 'decision_boundary'):
    X_min, X_max = X[:,0].min()-1, X[:,0].max()+1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(X_min, X_max, h), np.arange(y_min, y_max))
    label_predict = model.predict(np.stack((xx.flat, yy.flat), axis=1))
    label_predict = label_predict.reshape(xx.shape)
    plt.title(title,fontproperties=getChineseFont())
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())
    plt.xticks(())
    plt.yticks(())
    plt.contourf(xx, yy, label_predict, alpha = 0.5)
    markers = ['x','^','o']
    colors = ['b','r','c']
    classes = np.unique(y)

    for label in classes:
        plt.scatter(X[y==label][:,0], X[y==label][:,1],
                    c = colors[label], s=60, marker=markers[label])

    if draw_SV:
        SV = model.support_vectors_
        n = model.n_support_[0]
        plt.scatter(SV[:n,0], SV[:n,1], s=15, c='black', marker='o')
        plt.scatter(SV[n:,0], SV[n:,1], s=15, c='g', marker='o')

def Data_entsethen():
    X, y = make_circles(200, factor=0.1, noise=0.1)
    plt.scatter(X[y == 0, 0], X[y == 0, 1], c='b', s=20, marker='x')
    plt.scatter(X[y == 1, 0], X[y == 1, 1], c='r', s=20, marker='^')
    plt.xticks(())
    plt.yticks(())
    plt.title('数据集', fontproperties=getChineseFont(), size=20)
    plt.show()

def linear_und_unilinear():
    X, y = make_circles(200, factor=0.1, noise=0.1)
    # 调用SVC函数，分别构造线性核函数和三阶多项式核函数的SVM
    plt.figure(figsize=(12, 10), dpi=200)
    model_linear = SVC(C=1.0, kernel='linear')
    model_linear.fit(X, y)
    plt.subplot(2, 2, 1)
    plot_decision_boundary(model_linear, X, y, title='线性核函数')
    print("采用线性核函数生成的支持向量个数：", model_linear.n_support_)

    model_poly = SVC(C=1.0, kernel='poly', degree=3, gamma="auto")
    model_poly.fit(X, y)
    plt.subplot(2, 2, 2)
    plot_decision_boundary(model_poly, X, y, title='多项式核函数')
    print("采用多项式函数生成的支持向量个数：", model_poly.n_support_)
    plt.show()

def rtf_Function():
    X, y = make_circles(200, factor=0.1, noise=0.1)
    plt.figure(figsize=(12,10),dpi=200)
    for j,gamma in enumerate((10,1,0.1,0.01)):
        plt.subplot(2,2,j+1)
        model_rtf = SVC(C=1.0, kernel='rbf', gamma=gamma)
        model_rtf.fit(X,y)
        plot_decision_boundary(model_rtf, X, y, title='rbf函数,参数gamma='+str(gamma))
        print("rbf函数,参数gamma=",str(gamma),"支持向量个数为：",model_rtf.n_support_)
    plt.show()

def Automatische_para_Finden():
    X, y = make_circles(200, factor=0.1, noise=0.1)
    tuned_parameters = [{'kernel':['rbf'], 'gamma':[1,0.1,0.01], 'C':[0.1,1,10]},
                        {'kernel':['linear'], 'C':[0.1,1,10]},
                        {'kernel':['poly'],'gamma':[1,0.1,0.01],'C':[0.1,1,10]}]
    model_grid = GridSearchCV(SVC(), tuned_parameters, cv=5)
    model_grid.fit(X,y)
    print("die besten Parameters sind %s mit bester Folge %0.2f"% (model_grid.best_params_,model_grid.best_score_))
    print(model_grid.best_index_,model_grid.best_estimator_,model_grid.best_params_['kernel'])
    
def Gamma_Grafik():
    score = []
    X, y = make_circles(200, factor=0.1, noise=0.1)
    gamma_range = np.logspace(-10, 1, 50)
    for i in gamma_range:
        model = SVC(kernel="rbf", gamma=i, cache_size=5000)
        model.fit(X,y)
        score_gamma = model.score(X, y)
        score.append(score_gamma)
    print("最大准确率：", max(score))
    print("对应的gamma值为：", gamma_range[score.index(max(score))])
    plt.xlabel("gamma取值",fontproperties=getChineseFont())
    plt.ylabel("准确率",fontproperties=getChineseFont())
    plt.title("gamma的学习曲线",fontproperties=getChineseFont())
    plt.plot(gamma_range,score)
    plt.show()

Gamma_Grafik()






