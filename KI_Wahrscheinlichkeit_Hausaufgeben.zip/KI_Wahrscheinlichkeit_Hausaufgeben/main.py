import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from functools import reduce

#plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]
def getChineseFont():
    return FontProperties(fname='/Users/enya/Documents/字体/新建文件夹 (2)/2.ttf')
plt.rcParams['axes.unicode_minus'] = False

def Discrete_pmf():
    xk = np.arange(5)
    pk = (1/16, 1/4, 3/8, 1/4, 1/16)
    dist = stats.rv_discrete(name='custm', values=(xk, pk))
    print(pk)
    rv = dist.rvs(size=100)
    fig, (ax0, ax1) = plt.subplots(ncols=2, figsize=(10, 5))

    ax0.set_title("概率函数",fontproperties=getChineseFont())
    ax0.plot(xk, pk, 'ro', ms=8, mec='r')
    ax0.vlines(xk, 0, pk, colors='r', linestyles='-', lw=2)
    print(pk)
    for i in xk:
        ax0.text(i, pk[i],'%.3f' % pk[i], ha='center', va='bottom')

    ax1.set_title("分布函数",fontproperties=getChineseFont())
    pk1 = dist.cdf(xk)
    print(pk1)
    ax1.hist(rv, 4, density=1, histtype='step', facecolor='blue', alpha=0.75, cumulative=True, rwidth=0.9)
    for i in xk:
        ax1.text(i, pk1[i], '%.3f' % pk1[i], ha='center', va='bottom')
    plt.show()

def test_norm_pmf():
    mu = 0
    sigma = 1
    x = np.arange(-5, 5, 0.1)
    y = (1 / (np.sqrt(2*np.pi*sigma*sigma)))*np.e**(-(((x-mu)**2)/(2*sigma*sigma)))
    fig, (ax0,ax1) = plt.subplots(ncols=2, figsize=(10,5))
    ax0.plot(x,y)
    ax1.plot(x,stats.norm.cdf(x, 0, 1))
    ax0.set_title('Normal: $\mu$=%1.f, $sigma^2$=%1.f' % (mu,sigma))
    ax0.set_xlabel('x')
    ax0.set_ylabel('Prebability density', fontsize=15)
    ax1.set_title('Normal: $\mu$=%1.f, $sigma^2$=%1.f' % (mu, sigma))
    ax1.set_xlabel('x')
    ax1.set_ylabel('Cumulative density', fontsize=15)
    fig.subplots_adjust(wspace=0.4)
    plt.show()

def Fun_arave_aufgabe1(n, r):
    if  r==0:
        P = np.e**(-n)
    else:
        P = (np.e**(-n)*(n**r))/Factorial(r)
    return P


def Factorial(n):
    return reduce(lambda x, y: x * y, range(1,n+1))

if  __name__ == '__main__':
    print(Fun_arave_aufgabe1(2, 0))
    print(Fun_arave_aufgabe1(2, 1))
    print(Fun_arave_aufgabe1(2, 2))
    print(Fun_arave_aufgabe1(2, 3))
    print(Fun_arave_aufgabe1(2, 4))
    Discrete_pmf()

