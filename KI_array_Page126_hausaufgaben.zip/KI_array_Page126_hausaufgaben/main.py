import numpy as np
from numpy import *
from sympy import *

def Fun_iden(array1, array2):  # 判断增广矩阵的秩和系数矩阵的秩
    A = array1
    B = array2.reshape(-1,1)
    AB = hstack((A, B))
    if(np.linalg.matrix_rank(A) == np.linalg.matrix_rank(AB)):
        return True
    else:
        return False

def Fun_xyz_Methode1(array1,array2):
    A_inv = np.linalg.inv(array1)
    B = array2.reshape(-1,1)
    return A_inv.dot(B)

def Fun_xyz_Methode2(array1, array2):
    A = array1
    B = array2.reshape(-1,1)
    X = np.linalg.solve(A,B)
    return X

A = array([[1, 1, 1],[1, 2, 4],[1, 3, 9]])
B = array([2, 3, 5])
res_1 = Fun_xyz_Methode1(A,B)
res_2 = Fun_xyz_Methode2(A,B)
if(Fun_iden(A,B)):
    print("方法一结果为：\n",res_1)
else:
    print("无法使用方法一")

if(Fun_iden(A,B)):
    print("方法二结果为：\n",res_2)
else:
    print("无法使用方法二")

if(allclose(res_1, res_2)):
    print("答案正确")
else:
    print("答案错误")
